<?php
    
    echo md5("adminpassword");

?>