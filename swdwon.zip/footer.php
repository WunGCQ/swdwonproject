<link rel="stylesheet" href="css/staticpage.css"/>
<div id="footer">
        <table>
            <tr>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>
            <tr>
                <td></td>
                <td> <strong>帮助说明</strong> </td>
                <td><a href="Delivery.php">配送方式</a></td>
                <td><a href="aftersale.php">售后服务</a></td>
                <td><a href="paymentHelp.php">付款帮助</a></td>
                <td> <a target="_blank" href="http://sighttp.qq.com/authd?IDKEY=0c872b3285efe23495d6a63dc6989c3fb3c013f41b851e0c"><img border="0" src="http://wpa.qq.com/imgd?IDKEY=0c872b3285efe23495d6a63dc6989c3fb3c013f41b851e0c&pic=51" alt="点击这里在线咨询" title="点击这里在线咨询"></a>
</td>
            </tr>
            <tr>
                <td></td>
                <td> <strong>关于我们</strong> </td>
                <td><a href="AboutUs.php">关于思维特</a></td>
                <td><a href="joinUs.php">加入我们</a></td>
                <td><a href="getInTouchWithUs.php">联系我们</a></td>
                <td><a href="legalNotices.php">法律声明</a></td>
                <td></td>
            </tr>
            <tr>
                <td colspan="7">
                    ©2014 Meizu Telecom EquipmentCo., Ltd. All rights reserved. 备案号：粤ICP备13003602号-2 经营许可证编号：粤B2-20130198 营业执照
                </td>
            </tr>
        </table>
</div>