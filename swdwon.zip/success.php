<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title>订单成功提交</title>
    <script src="js/jquery.min.js" type="text/javascript" charset="utf-8"></script>
    <script src="js/warning.js"></script>
    <script src="js/usercenter.js"></script>
    <script src="js/Shoppingcart.js"></script>
    <link rel="stylesheet" type="text/css" href="css/header.css"/>
    <link rel="stylesheet" type="text/css" href="css/footer.css"/>
    <link rel="stylesheet" type="text/css" href="css/model-window.css"/>
    <link rel="stylesheet" href="css/shoppping.css"/>
    <!--<link rel="stylesheet" type="text/css" href="css/user-center.css"/>-->
    <link rel="stylesheet" href="css/warning.css"/>
</head>
<body>
    <?php include("header.php"); ?>
    <div id="container">
        <div id="shoppingcart-null">
            恭喜您！你的订单已经成功提交，请等待网站管理员与您联系~
            <a href="http://index.php">再去逛逛</a>
        </div>
    </div>
    <?php include("footer.php"); ?>
</body>